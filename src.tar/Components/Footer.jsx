import React from 'react';
const Footer = () => {
    return(
        <footer>
            <section>
                <div>
                    <p>&copy; Ron's Planning LLC. All rights reserved</p>
                </div>
            </section>
        </footer>
    )
}
export default Footer;